onerror {quit -f -code 1}
onbreak {quit -f}
run -all
quit -f
